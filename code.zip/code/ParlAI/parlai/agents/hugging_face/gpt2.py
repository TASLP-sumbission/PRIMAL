#!/usr/bin/env python3

# Copyright (c) Facebook, Inc. and its affiliates.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from typing import Optional
from parlai.core.params import ParlaiParser
from parlai.core.opt import Opt
import os

import torch
from parlai.agents.hugging_face.dict import Gpt2DictionaryAgent
from parlai.core.torch_generator_agent import TorchGeneratorAgent, TorchGeneratorModel
from parlai.utils.io import PathManager
from parlai.utils.misc import warn_once
from parlai.utils.torch import IdentityLayer, padded_tensor
from parlai.core.torch_agent import Batch, TorchAgent
from transformers.generation_utils import DIYGenerationMixin


try:
    from transformers import GPT2Model
except ImportError:
    raise ImportError("Please run `pip install transformers`.")


############################################
## Modules
############################################


class GPT2Decoder(torch.nn.Module):
    """
    GPT2 Decoder.

    This decoder is initialized with the pretrained model from Hugging Face.
    """

    def __init__(self, opt, dict):
        super().__init__()
        self.transformer = self._init_from_pretrained(opt)
        # add special tokens
        if opt["add_special_tokens"]:
            size_before = self.transformer.wte.weight.size(0)
            self.transformer.resize_token_embeddings(len(dict.hf_tokenizer))
            with torch.no_grad():
                # first reduce the random jitter of the initialization
                self.transformer.wte.weight[size_before:] *= 0.1
                # next center it on the endoftext token
                self.transformer.wte.weight[
                    size_before:
                ] += self.transformer.wte.weight[size_before - 1].unsqueeze(0)
        if opt['freeze']:
            for name, param in self.transformer.named_parameters():
                if "softprompts" not in name:
                    param.requires_grad = False

        self.add_start_token = opt["add_start_token"]
        self.START_IDX = dict.start_idx
        self.NULL_IDX = dict.null_idx
        self.END_IDX = dict.end_idx
        # use cuda
        self.use_cuda = not opt["no_cuda"] and torch.cuda.is_available()

    def _init_from_pretrained(self, opt):
        return GPT2Model.from_pretrained(opt["gpt2_path"])
        # load model
        # model_sz = opt["gpt2_size"]
        # if model_sz == "small":
        #     model_key = "gpt2"
        # elif model_sz == "distilgpt2":
        #     model_key = "distilgpt2"
        # else:
        #     model_key = f"gpt2-{model_sz}"
        #
        # # check if datapath has the files that hugging face code looks for
        # hf_dir = os.path.join(opt["datapath"], "hf", model_key)
        # if all(
        #     PathManager.exists(os.path.join(hf_dir, file_name))
        #     for file_name in ["pytorch_model.bin", "config.json"]
        # ):
        #     fle_key = PathManager.get_local_path(hf_dir, recursive=True)
        # else:
        #     fle_key = model_key
        # #GPT2Model.from_pretrained(fle_key,cache_dir=opt["gpt2_path"])


    def forward(self, input, encoder_state, incr_state=None):
        attention_mask = None
        position_ids = None
        if incr_state is None:
            # first step
            if (
                not self.add_start_token
                and input.size(1) == 1
                and int(input[0][0]) == self.START_IDX
            ):
                # generating: ignore the start token
                # without deep copy, the padding_idx (-1) in encoder_state can be reset to 0 with clamp_ inplace operation
                model_input = encoder_state.clone()
            else:
                if (
                        not self.add_start_token
                        and int(input[0][0]) == self.START_IDX
                ):
                    input = input[:, 1:]
                # forced decoding: concatenate the context
                # with the labels
                model_input = torch.cat([encoder_state, input], dim=-1)
            attention_mask = model_input != self.NULL_IDX
            position_ids = (
                attention_mask.cumsum(dim=-1, dtype=torch.int64) - 1
            ).clamp_(min=0)
        else:
            if not self.add_start_token:
                input = input[:, 1:]
            # generating with continuation
            # get the position ids
            position_ids = (encoder_state != self.NULL_IDX).sum(
                -1, True, dtype=torch.int64
            ) - 1
            delta = ((input != self.NULL_IDX)).sum(-1, True, dtype=torch.int64)
            position_ids += delta
            # generation: get the last token input
            model_input = input[:, -1:]
            attention_mask = torch.cat([encoder_state, input], dim=-1) != self.NULL_IDX

        model_input = model_input.clamp_(min=0)
        transformer_outputs = self.transformer(
            model_input,
            past_key_values=incr_state,
            use_cache=False,
            attention_mask=attention_mask,
            position_ids=position_ids,
        )
        hidden_states = transformer_outputs[0]
        #new_incr_state = transformer_outputs[1]

        if incr_state is None:
            # pull out only the hidden states for the label tokens
            if int(input[0][0]) == self.START_IDX:
                output = hidden_states[:,-1:]
            else:
                output = hidden_states[:, -input.size(1) - 1 + int(self.add_start_token) :]
                # hack: we need the last state of the encoder-side to be the first
                # element of the decoder-side
                lengths = (input != self.NULL_IDX).sum(dim=-1)
                for i in range(input.size(0)):
                    output[i, input.size(1) - lengths[i]] = output[i, 0]

        else:
            # generation, we're only doing one token at a time. no need to
            # shove things back in
            output = hidden_states

        return output, None


class HFGPT2Model(TorchGeneratorModel,DIYGenerationMixin):
    """
    Hugging Face GPT2 Model.

    GPT2 is a multi-layer decoder-only Transformer. As such, the encoder
    is simply an identity layer. The decoder is initialized with pretrained
    weights from Hugging Face. Read more about this model here
    <https://huggingface.co/transformers/model_doc/gpt2.html>.
    """

    def __init__(self, opt, dict):
        self.add_start_token = opt["add_start_token"]
        super().__init__(*self._get_special_tokens(opt, dict))

        # init the model
        self.encoder = IdentityLayer()
        self.decoder = self._get_decoder(opt, dict)
        self.config = self.decoder.transformer.config
        self.lm_head = torch.nn.Linear(
            self.config.n_embd, self.config.vocab_size, bias=False
        )
        self._tie_weights(self.lm_head, self.decoder.transformer.wte)
        # add start token

    def _get_decoder(self, opt, dict):
        return GPT2Decoder(opt, dict)

    def _tie_weights(self, output_embeddings, input_embeddings):
        output_embeddings.weight = input_embeddings.weight

    def _get_special_tokens(self, opt, dict):
        return dict.null_idx, dict.start_idx, dict.end_idx

    def reorder_encoder_states(self, encoder_states, indices):
        enc = torch.index_select(encoder_states, 0, indices)
        return enc

    def output(self, tensor):
        """
        Compute output logits.
        """
        return self.lm_head(tensor)

    def reorder_decoder_incremental_state(self, incremental_state, inds):
        new_incr_state = []
        for layer_past in incremental_state:
            if torch.is_tensor(layer_past):
                new_incr_state.append(torch.index_select(layer_past, 1, inds))
            else:
                # newer versions of HF split up the intermediate outputs
                assert isinstance(layer_past, tuple)
                layer_past = torch.stack(layer_past, dim=0)
                new_incr_state.append(torch.index_select(layer_past, 1, inds))

        return tuple(new_incr_state)

    def forward(self, *xs, ys=None,train=True, prev_enc=None,incr_state = None, maxlen=None, bsz=None):

        #T5 procedure
        assert ys is not None, "Greedy decoding in TGModel.forward no longer supported."
        # TODO: get rid of longest_label
        # keep track of longest label we've ever seen
        # we'll never produce longer ones than that during prediction
        self.longest_label = max(self.longest_label, ys.size(1))
        #print("x",xs)
        # use cached encoding if available
        encoder_states = prev_enc if prev_enc is not None else self.encoder(xs[0])
        #print("encoder_states after encoder",encoder_states[0].shape)
        # use teacher forcing
        if train:
            scores, preds = self.decode_forced(encoder_states, ys)
            return scores, preds
        else:
            scores, incr_state = self.eval_decode_forced(encoder_states, ys, incr_state)
            return scores, incr_state


    def _get_initial_forced_decoder_input(self, bsz: int, inputs: torch.LongTensor):
        tens = (
            torch.LongTensor([self.START_IDX])  # ,
                .to(inputs)
                .detach()
                .expand(bsz, 1)
        )

        return torch.cat([tens, inputs], 1)


    def eval_decode_forced(self, encoder_states, decoder_input,incr_state):

        score, incr_state = self.decoder(decoder_input,encoder_states, incr_state)
        logits = self.output(score)

        return logits, incr_state


    def decode_forced(self, encoder_states, ys):
        """
        Override to get rid of start token input.
        """
        if self.add_start_token:
            return super().decode_forced(encoder_states, ys)
        seqlen = ys.size(1)
        inputs = ys.narrow(1, 0, seqlen - 1)
        #print("decoder inputs",inputs)
        latent, _ = self.decoder(inputs, encoder_states)
        logits = self.output(latent)
        _, preds = logits.max(dim=2)
        return logits, preds


############################################
## Agent
############################################


class Gpt2Agent(TorchGeneratorAgent):
    """
    Hugging Face GPT2 Agent.

    GPT2 is a multi-layer decoder-only Transformer.
    The decoder is initialized with pretrained weights from Hugging Face.
    Read more about this model here
    <https://huggingface.co/transformers/model_doc/gpt2.html>.

    GPT2 comes in five sizes: distilgpt2, small, medium, large, XL. Use the
    flag `--gpt2-size` to choose the size.

    If you are finetuning the Gpt2 agent as a dialogue agent, be sure
    to run `--add-special-tokens True`. To examine the performance of the
    agent out of the box, run with `--add-special-tokens False`, and make
    sure that the batch size is 1.
    """

    @classmethod
    def add_cmdline_args(
        cls, parser: ParlaiParser, partial_opt: Optional[Opt] = None
    ) -> ParlaiParser:
        agent = parser.add_argument_group("Gpt2 Args")
        agent.add_argument(
            "--gpt2-size",
            type=str,
            default="small",
            choices=["small", "medium", "large", "xl", "distilgpt2"],
            help="Which size model to initialize.",
        )
        agent.add_argument(
            "--add-special-tokens",
            type="bool",
            default=True,
            help="Add special tokens (like PAD, etc.). If False, "
            "Can only use with batch size 1.",
        )
        agent.add_argument(
            "--add-start-token",
            type="bool",
            default=False,
            help="Add start tokens when finetuning.",
        )
        agent.add_argument(
            '--left-pad',
            type="bool",
            default=False,
            help='',
        )
        parser.set_defaults(
            text_truncate=768,
            label_truncate=256,
            dict_maxexs=0,  # skip building dictionary
        )
        super().add_cmdline_args(parser, partial_opt=partial_opt)
        warn_once("WARNING: this model is in beta and the API is subject to change.")
        return agent

    def __init__(self, opt, shared=None):
        # editted to distinguish lm3 whiling loading
        self.size = opt["gpt2_size"]

        if not opt["add_special_tokens"] and opt.get('batchsize', 1) > 1:
            # *** STOP ***
            # You may be a future researcher who has stumbled upon this odd
            # restriction, and is tempted to comment this out. After all, the
            # code still runs when it's uncommented, why shouldn't you?
            # You should know this has serious implications, as gpt2 doesn't have
            # padding tokens. This is incompatible with ParlAI's batching,
            # which puts conversations of different length in the same
            # batch. Without a padding token, nonsense will be inserted into
            # the context, and the generations & PPL you get will be wrong.
            raise RuntimeError(
                "If using batchsize > 1, --add-special-tokens must be True."
            )
            pass
        if not opt["add_special_tokens"] and opt["add_start_token"]:
            raise RuntimeError(
                "--add-start-token true requires --add-special-tokens true"
            )
        super().__init__(opt, shared)
        if hasattr(self.model, "module"):
            self.START_IDX = self.model.module.START_IDX
            self.END_IDX = self.model.module.END_IDX
            self.NULL_IDX = self.model.module.NULL_IDX
        else:
            self.START_IDX = self.model.START_IDX
            self.END_IDX = self.model.END_IDX
            self.NULL_IDX = self.model.NULL_IDX
        self.left_pad = opt["left_pad"]
        pass

    @staticmethod
    def dictionary_class():

        return Gpt2DictionaryAgent

    def build_model(self, states=None):

        return HFGPT2Model(self.opt, self.dict)

    def _encoder_input(self, batch):
        return (batch.text_vec,)

    def _pad_tensor(self, items):
        """
        Override to always set fp16friendly to False and left_pad to True.
        """
        return padded_tensor(
            items, pad_idx=self.NULL_IDX, left_padded=self.left_pad, fp16friendly=False
        )

    def load_state_dict(self, state_dict):
        # 2020-11-10: some very old transformer model points (pre v3.0.1) are
        # missing a field called transformer.h.0.attn.masked_bias. This hacks
        # around that. See
        # https://github.com/huggingface/transformers/issues/4309.
        current_sd = self.model.state_dict()
        missing = set(current_sd.keys()) - set(state_dict.keys())
        for m in missing:
            if 'masked_bias' in m:
                state_dict[m] = current_sd[m]
        return super().load_state_dict(state_dict)

    def _set_text_vec(self, obs, history, truncate):
        """
        Set the 'text_vec' field in the observation.

        Useful to override to change vectorization behavior
        """
        if 'text' not in obs:
            return obs

        if 'text_vec_gpt2' not in obs:
            # text vec is not precomputed, so we set it using the history
            history_string = history.get_history_str()
            # when text not exist, we get text_vec from history string
            # history could be none if it is an image task and 'text'
            # filed is be empty. We don't want this
            if history_string is None:
                return obs
            #obs['full_text'] = history_string
            if history_string:
                obs['text_vec_gpt2'] = history.get_history_vec()
                obs['full_text_vec_gpt2'] = history.get_history_vec()


        # check truncation
        if obs.get('text_vec_gpt2') is not None:
            truncate_left = not self.history_reversed
            text_length = len(obs['text_vec_gpt2'])
            truncated_vec = self._check_truncate(
                obs['text_vec_gpt2'], truncate, truncate_left
            )
            obs.force_set('gpt2_context_original_length', text_length)
            obs.force_set('gpt2_context_truncate_rate', text_length != len(truncated_vec))
            obs.force_set(
                'gpt2_context_truncated_length', max(text_length - len(truncated_vec), 0)
            )
            obs.force_set('text_vec_gpt2', torch.LongTensor(truncated_vec))

        return obs

    def _set_label_vec(self, obs, add_start, add_end, truncate):
        """
        Set the 'labels_vec' field in the observation.

        Useful to override to change vectorization behavior
        """
        # convert 'labels' or 'eval_labels' into vectors
        if 'labels' in obs:
            label_type = 'labels'
        elif 'eval_labels' in obs:
            label_type = 'eval_labels'
        else:
            label_type = None

        if label_type is None:
            return

        elif label_type + '_vec_gpt2' in obs:
            # check truncation of pre-computed vector
            vec_label_length = len(obs[label_type + '_vec_gpt2'])
            truncated_vec = self._check_truncate(obs[label_type + '_vec_gpt2'], truncate)
            obs.force_set('gpt2_label_original_length', vec_label_length)
            obs.force_set('gpt2_label_truncate_rate', vec_label_length > len(truncated_vec))
            obs.force_set(
                'gpt2_label_truncated_length', max(vec_label_length - len(truncated_vec), 0)
            )
            obs.force_set(label_type + '_vec_gpt2', torch.LongTensor(truncated_vec))
        else:
            # pick one label if there are multiple
            lbls = obs[label_type]
            label = lbls[0] if len(lbls) == 1 else self.random.choice(lbls)
            (
                vec_label,
                vec_label_length,
                vec_label_truncated,
            ) = self._vectorize_text_with_truncate_stats(
                label, add_start, add_end, truncate, False
            )
            obs.force_set('gpt2_label_original_length', vec_label_length)
            obs.force_set('gpt2_label_truncate_rate', vec_label_truncated)
            obs.force_set(
                'gpt2_label_truncated_length', max(vec_label_length - len(vec_label), 0)
            )
            obs[label_type + '_vec_gpt2'] = vec_label

        return obs

    def vectorize(
        self,
        obs,
        history,
        add_start=True,
        add_end=True,
        text_truncate=None,
        label_truncate=None,
    ):
        add_start = False
        add_end = True
        self._set_text_vec(obs, history,text_truncate)
        self._set_label_vec(obs, add_start, add_end, label_truncate)

        return obs


