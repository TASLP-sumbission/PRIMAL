# Repeat Query

This is an agent which simply repeats the query for debugging purposes or as a baseline.

## Basic Examples

Evaluate on bAbi, displaying the answers.
```bash
parlai display_model -m repeat_query -t babi
```
