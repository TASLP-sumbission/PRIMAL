#!/usr/bin/env python3

# Copyright (c) Facebook, Inc. and its affiliates.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
"""
T5: Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer

See <https://arxiv.org/abs/1910.10683>

The T5 agent can be instantiated as simply `-m t5`
"""
import json,copy
import torch
import random
import torch.nn as nn
from typing import Optional, Dict, Any, Tuple
from transformers import T5ForConditionalGeneration
from transformers.generation_utils import DIYGenerationMixin

try:
    from transformers.models.t5.soft_prompt_modeling_t5 import T5Stack
except ModuleNotFoundError:
    # Prior versions of transformers package do not have T5Stack
    T5Stack = object

from parlai.agents.hugging_face.gpt2 import HFGPT2Model,Gpt2Agent
from parlai.agents.bart.bart import BartAgent


from parlai.agents.hugging_face.hugging_face import HF_VERSION
from parlai.agents.hugging_face.dict import T5DictionaryAgent,Gpt2DictionaryAgent

from parlai.core.opt import Opt
from parlai.core.params import ParlaiParser
from parlai.core.torch_agent import Batch, TorchAgent
from parlai.core.torch_generator_agent import TorchGeneratorAgent, TorchGeneratorModel
from parlai.utils.torch import atomic_save
from parlai.utils.io import PathManager
import parlai.utils.logging as logging


def build_t5(opt: Opt) -> T5ForConditionalGeneration:
    if not HF_VERSION >= 4.3:
        raise RuntimeError('Must use transformers package >= 4.3 to use t5')
    return T5ForConditionalGeneration.from_pretrained(
        opt['t5_model_arch'], dropout_rate=opt['t5_dropout']
    )

###########################################################################
# Task-specific generation configs for T5.                                #
# Taken from HF: https://huggingface.co/t5-small/resolve/main/config.json #
###########################################################################

TASK_CONFIGS = {
    "dialogue": {
        "early_stopping": True,
        "length_penalty": 2.0,
        "max_length": 200,
        "min_length": 30,
        "no_repeat_ngram_size": 3,
        "num_beams": 4,
        "prefix": "Person1 ",
    },
    "summarization": {
        "early_stopping": True,
        "length_penalty": 2.0,
        "max_length": 200,
        "min_length": 30,
        "no_repeat_ngram_size": 3,
        "num_beams": 4,
        "prefix": "summarize: ",
    },
    "translation_en_to_de": {
        "early_stopping": True,
        "max_length": 300,
        "num_beams": 4,
        "prefix": "translate English to German: ",
    },
    "translation_en_to_fr": {
        "early_stopping": True,
        "max_length": 300,
        "num_beams": 4,
        "prefix": "translate English to French: ",
    },
    "translation_en_to_ro": {
        "early_stopping": True,
        "max_length": 300,
        "num_beams": 4,
        "prefix": "translate English to Romanian: ",
    },
}
''

class MultiLmAgent(TorchGeneratorAgent):
    @classmethod
    def add_cmdline_args(
        cls, parser: ParlaiParser, partial_opt: Optional[Opt] = None
    ) -> ParlaiParser:
        super().add_cmdline_args(parser, partial_opt=partial_opt)
        group = parser.add_argument_group('LM Args')
        group.add_argument(
            "--gpt2-size",
            type=str,
            default="small",
            choices=["small", "medium", "large", "xl", "distilgpt2"],
            help="Which size model to initialize.",
        )
        group.add_argument(
            "--lm3-size",
            type=str,
            default="small",
            choices=["small", "medium", "large", "xl", "distilgpt2"],
            help="Which size model to initialize.",
        )
        group.add_argument(
            '--bart-path',
            type=str,
            default=None,
            help='',
        )
        group.add_argument(
            '--gpt2-path',
            type=str,
            default=None,
            help='',
        )
        group.add_argument(
            '--lm3-path',
            type=str,
            default=None,
            help='',
        )
        group.add_argument(
            '--train-lm3',
            type='bool',
            default=False,
            help='use few-shot train data',
        )
        group.add_argument(
            '--train-gpt2',
            type='bool',
            default=False,
            help='use few-shot train data',
        )
        group.add_argument(
            '--train-bart',
            type='bool',
            default=False,
            help='use few-shot train data',
        )
        group.add_argument(
            "--add-special-tokens",
            type="bool",
            default=True,
            help="Add special tokens (like PAD, etc.). If False, "
            "Can only use with batch size 1.",
        )
        group.add_argument(
            "--add-start-token",
            type="bool",
            default=False,
            help="Add start tokens when finetuning.",
        )
        group.add_argument(
            '--init-fairseq-model',
            type=str,
            default=None,
            help='fairseq checkpoint for bart',
        )
        group.add_argument(
            '--output-conversion-path',
            type=str,
            default=None,
            help='where to save fairseq conversion',
        )
        group.add_argument(
            '--t5-model-arch',
            type=str,
            default='t5-base',
            choices=["t5-small", "t5-base", "t5-large", "t5-3b", "t5-11b"],
        )
        group.add_argument(
            '--t5-model-parallel',
            type='bool',
            default=False,
            help='use HF model parallel',
        )
        group.add_argument(
            '--t5-dropout', type=float, default=0.0, help='Dropout for T5'
        )
        group.add_argument(
            '--sentence-temperature', type=float, default=1.0, help='temp for sentence level sampling'
        )
        group.add_argument(
            '--t5-generation-config',
            type=str,
            default=None,
            choices=[
                'dialogue',
                'summarization',
                'translation_en_to_de',
                'translation_en_to_fr',
                'translation_en_to_ro',
            ],
            help='Task specific generation config for T5',
        )
        ####DIY configs
        group.add_argument(
            '-sps', '--soft-prompt-num', type=int, default=100, help='soft-prompt-size.'
        )
        group.add_argument(
            '--freeze',
            type='bool',
            default=True,
            help='use few-shot train data',
        )

        parser.set_defaults(
            text_truncate=768,
            label_truncate=256,
            dict_maxexs=0,  # skip building dictionary
        )
        return parser

    def build_model(self) -> 'SofpromptT5Model':
        model = MultiLMModel(self.opt, self.dict)
        if self.opt['t5_model_parallel']:
            model.t5.parallelize()
        return model

    def build_dictionary(self):
        # return T5DictionaryAgent(self.opt)
        lm3_opt = self.opt
        return Gpt2DictionaryAgent(lm3_opt)

    def vectorize(self,observation, history,text_truncate,label_truncate):
        add_start = False  # model does this in module code
        add_end = True  # T5 tokenizer takes care of this
        #if self.model.train_lm3:
        observation = TorchAgent.vectorize(self,observation,history,add_start,add_end,text_truncate,label_truncate)
        if self.model.train_gpt2:
            observation = self.model.gpt2.vectorize(observation,self.model.gpt2.history,add_start,add_end,text_truncate,label_truncate)
        if self.model.train_bart:
            observation = self.model.bart.vectorize(observation,self.model.bart.history,add_start,add_end,text_truncate,label_truncate)

        return observation

    def save(self, path=None):

        if self.model.train_lm3:
            path = self.opt.get('model_file', None) if path is None else path
            if path:
                model_dict_path = path + '.dict'
                if hasattr(self, 'dict') and not PathManager.exists(
                    model_dict_path
                ):  # force save dictionary
                    # TODO: Look into possibly overriding opt('dict_file') with new path
                    logging.debug(f'Saving dictionary to {model_dict_path}')
                    self.dict.save(model_dict_path, sort=False)
                states = self.state_dict()
                if states:  # anything found to save?
                    atomic_save(states, path)
                    # save opt file
                    self.opt.save(path + '.opt')

        if self.model.train_gpt2:
            self.model.gpt2.save(path=self.opt["model_file"]+"_gpt2")
        if self.model.train_bart:
            self.model.bart.save(path=self.opt["model_file"]+"_bart")
        if self.model.train_lm3:
            self.model.bart.save(path=self.opt["model_file"]+"_lm3")
    def observe(self, observation):
        """
        Override to include prefix, if necessary.
        """
        if self.opt['t5_generation_config'] is not None and 'text' in observation:
            config = TASK_CONFIGS[self.opt['t5_generation_config']]
            try:
                observation.force_set('text', config['prefix'] + observation['text'])
            except AttributeError:
                observation['text'] = config['prefix'] + observation['text']

        return super().observe(observation)

    def _generate(
        self,
        batch: Batch,
        beam_size: int,
        max_ts: int,
        prefix_tokens: Optional[torch.LongTensor] = None,
        overrides: Optional[Dict[str, Any]] = None,
    ):
        """
        Generate an output with beam search.
        Use HF's built-in generation to perform beam search.
        """
        bad_words_ids = None
        if self.beam_block_list is not None:
            bad_words_ids = [
                gram for _, ngram in self.beam_block_list.items() for gram in ngram
            ]

        method = self.opt.get('inference', 'greedy')
        cuda_num = 0 if "0" in self.model.device else 1
        init_lm1_entropy = torch.load(self.opt['model_file'].replace("model_gpt2","bart_entropy.pt"),map_location=lambda storage, loc: storage.cuda(cuda_num))#.to(self.model.device)
        init_lm2_entropy = torch.load(self.opt['model_file'].replace("model_gpt2","gpt2_entropy.pt"),map_location=lambda storage, loc: storage.cuda(cuda_num))#.to(self.model.device)
        init_lm3_entropy = torch.load(self.opt['model_file'].replace("model_gpt2","lm3_entropy.pt"),map_location=lambda storage, loc: storage.cuda(cuda_num))#.to(self.model.device)
        lm1_entropy = init_lm1_entropy
        lm2_entropy = init_lm2_entropy
        lm3_entropy = init_lm3_entropy
        for i in range(beam_size-1):
            lm1_entropy = torch.cat([lm1_entropy, init_lm1_entropy])
            lm2_entropy = torch.cat([lm2_entropy, init_lm2_entropy])
            lm3_entropy = torch.cat([lm3_entropy, init_lm3_entropy])

        ys1,ys2,ys3 = None,None,None
        input_ids,input_xs2,input_xs3 = None,None,None
        attention_mask_xs1, attention_mask_xs2,attention_mask_xs3 = None,None, None

        if self.model.train_bart:
            input_ids = batch.text_vec_bart
            ys1 = batch.label_vec_bart
            temp_ = batch.text_vec_bart != self.model.bart.model.NULL_IDX
            attention_mask_xs1 = torch.cat((torch.full([batch.text_vec_bart.size()[0], 100], True).to(batch.text_vec_bart.device), temp_), dim=1)

        if self.model.train_gpt2:
            input_xs2 = batch.text_vec_gpt2
            ys2 = batch.label_vec_gpt2
            temp_xs2 = batch.text_vec_gpt2 != self.model.gpt2.model.NULL_IDX
            attention_mask_xs2 = torch.cat((torch.full([batch.text_vec_gpt2.size()[0], 200], True).to(batch.text_vec_gpt2.device), temp_xs2), dim=1)

        if self.model.train_lm3:
            input_xs3 = batch.text_vec
            ys3 = batch.label_vec
            temp_xs3 = batch.text_vec != self.NULL_IDX
            attention_mask_xs3 = torch.cat((torch.full([batch.text_vec.size()[0], 100], True).to(batch.text_vec.device), temp_xs3), dim=1)

        generation_params = {
            'input_ids': input_ids,
            'input_xs2': input_xs2,
            'input_xs3': input_xs3,
            'ys1':ys1,
            'ys2':ys2,
            'ys3':ys3,
            'dict_xs1':self.model.dict_bart,
            'dict_xs2':self.model.dict_gpt2,
            'dict_xs3':self.model.dict_lm3,
            'lm1_entropy': lm1_entropy,
            'lm2_entropy': lm2_entropy,
            'lm3_entropy': lm3_entropy,
            'decode_w_entropy': self.opt['decode_w_entropy_scale'],
            'incr_state_gpt2':None,
            'max_length': 40,#self.opt['max_len'],#40 max_ts,
            'min_length': self.beam_min_length,
            'do_sample': self.opt['inference'] in ['topk', 'topp','nucleus'],
            'early_stopping': None,
            'num_beams': beam_size,
            'temperature': self.temperature,
            'sentence_temperature':self.opt['sentence_temperature'],
            'top_k': self.opt['topk'] if method in ['topk', 'delayedbeam'] else None,
            'top_p': self.opt['topp'] if method in ['nucleus'] else None,
            'repetition_penalty': None,
            'bad_words_ids': bad_words_ids if bad_words_ids else None,
            'bos_token_id': self.model.bart.START_IDX,
            'pad_token_id': self.model.bart.NULL_IDX,
            'eos_token_id': self.model.bart.END_IDX,
            'length_penalty': self.opt['beam_length_penalty'],
            'no_repeat_ngram_size': self.beam_block_ngram,
            'num_return_sequences': None,
            'attention_mask': attention_mask_xs1,
            'attention_mask_xs2': attention_mask_xs2,
            'attention_mask_xs3': attention_mask_xs3,
            'decoder_start_token_id': self.model.bart.START_IDX,
        }

        if overrides:
            generation_params.update(overrides)

        outputs, scores, outputs_xs2, scores_gpt2, outputs_xs3, scores_lm3= self.model.generate(**generation_params)
        outputs = [(outputs[i], 0) for i in range(outputs.size(0))]
        outputs_xs2 = [(outputs_xs2[i], 0) for i in range(outputs_xs2.size(0))]
        outputs_xs3 = [(outputs_xs3[i], 0) for i in range(outputs_xs3.size(0))]
        return outputs, [],scores, outputs_xs2,[],scores_gpt2, outputs_xs3, [],scores_lm3

##############
# T5 Modules #
##############
class ParlaiT5Encoder(torch.nn.Module):
    def __init__(self, opt: Opt, encoder: T5Stack, padding_idx: Optional[int] = None):
        super().__init__()
        self.opt = opt
        self.stack = encoder
        self.padding_idx = padding_idx
        self.paralleled = not opt[
            't5_model_parallel'
        ]  # need to parallel in forward; bug in HF

    #@set_device
    def forward(
        self,
        input: torch.LongTensor,
        positions: Optional[torch.LongTensor] = None,
        segments: Optional[torch.LongTensor] = None,
    ) -> Tuple[torch.Tensor, torch.BoolTensor]:

        if not self.paralleled:
            self.stack.parallelize()
        mask = input != self.padding_idx

        #add mask token for soft prompts in a batch
        mask = torch.cat((torch.full([input.size()[0], self.opt["soft_prompt_num"]], True).to(input.device), mask), dim=1)

        # softprompt will be added in the forward method of self.stack()
        outputs = self.stack(input, attention_mask=mask, output_hidden_states=False)
        for k in outputs:
            if torch.is_tensor(outputs[k]):
                outputs[k] = outputs[k].to(input.device)
        return outputs[0], mask

class ParlaiT5Decoder(torch.nn.Module):
    def __init__(self, opt: Opt, decoder: T5Stack, padding_idx: Optional[int] = None):
        super().__init__()
        self.stack = decoder
        self.padding_idx = padding_idx
        self.paralleled = not opt[
            't5_model_parallel'
        ]  # need to parallel in forward; bug in HF

    #@set_device
    def forward(
        self, input: torch.LongTensor, encoder_state: Tuple[Any], incr_state=None
    ):
        if not self.paralleled:
            self.stack.parallelize()
        encoder_output, encoder_mask = encoder_state

        mask = input != self.padding_idx
        mask[:, 0] = True  # first token is pad

        outputs = self.stack(
            input_ids=input,
            attention_mask=mask,
            encoder_hidden_states=encoder_output.to(input.device),
            encoder_attention_mask=encoder_mask.to(input.device),
        )
        return outputs[0].to(input.device), incr_state


class MultiLMModel(TorchGeneratorModel,DIYGenerationMixin):

    def __init__(self, opt, dictionary):
        self.pad_idx = dictionary[dictionary.null_token]
        self.start_idx = self.pad_idx
        self.end_idx = dictionary[dictionary.end_token]
        super().__init__(self.pad_idx, self.start_idx, self.end_idx)

        self.dict_lm3, self.dict_gpt2, self.dict_bart = None, None, None

        self.train_gpt2 = opt['train_gpt2']
        self.train_bart= opt['train_bart']
        self.train_lm3 = opt['train_lm3']

        gpt_opt = copy.deepcopy(opt)
        lm3_opt = copy.deepcopy(opt)
        lm3_opt["gpt2_path"] = lm3_opt["lm3_path"]
        lm3_opt["gpt2_size"] = lm3_opt["lm3_size"]
        lm3_opt['model_file'] = lm3_opt['model_file'].replace("model_gpt2", "model_lm3")
        #gpt_opt['init_model'] = opt['lm3_path'] + "//pytorch_model.bin "
        #gpt_opt['left_pad'] = False
        self.dict = Gpt2DictionaryAgent(lm3_opt)
        self.placeholder_lm3 = HFGPT2Model(lm3_opt,self.dict).to("cpu")
        #self.config = self.lm3.config
        # print(self.dict.txt2vec("\n"))

        if not opt["no_cuda"]:
            self.device = "cuda:"+str(opt["gpu"]) # TODO modify the assignment of self.device
        else:
            self.device = "cpu"

        if self.train_lm3:
            # lm3_opt["gpt2_path"] = lm3_opt["lm3_path"]
            # lm3_opt["gpt2_size"] = lm3_opt["lm3_size"]
            # lm3_opt['model_file'] = lm3_opt['model_file'].replace("model_gpt2","model_lm3")
            self.lm3 = Gpt2Agent(lm3_opt)
            self.dict_lm3 = self.lm3.dict

        if self.train_gpt2:
            self.gpt2 = Gpt2Agent(gpt_opt)
            self.dict_gpt2 = self.gpt2.dict
            self.config = self.gpt2.model.config


        if self.train_bart:
            file = open(opt['model_file'].replace("_gpt2","_bart")+'.opt', 'r')
            dic = json.loads(file.read())
            dic = Opt(dic)
            dic['datapath'] = opt['datapath']
            #dic['init_model'] = opt['model_file']
            dic['gpu'] = opt['gpu']
            dic['no_cuda'] = opt['no_cuda']
            #dic['activation'] = "gelu"
            # dic['validation_every_n_epochs'] = opt['validation_every_n_epochs']
            # dic['fp16'] = True
            # dic['force_fp16_tokens'] = True
            # dic['task'] = opt['task']
            # dic['beam_size'] = opt['beam_size']
            # dic['skip_generation'] = opt['skip_generation']
            # dic['split_lines'] = opt['split_lines']
            # dic['gpu'] = opt['gpu']
            # dic['batchsize'] = opt['batchsize']
            # dic['learningrate'] = opt['learningrate']
            # dic['freeze'] = opt['freeze']

            self.bart = BartAgent(dic,shared=None)
            self.dict_bart = self.bart.dict
        pass
    def reorder_encoder_states(self, encoder_states, indices):
        """
        Reorder the encoder states.
        See ``TorchGeneratorModel.reorder_encoder_states`` for a description.
        """
        enc, mask = encoder_states
        if not torch.is_tensor(indices):
            indices = torch.LongTensor(indices).to(enc.device)
        enc = torch.index_select(enc, 0, indices)
        mask = torch.index_select(mask, 0, indices)
        return enc, mask

    def get_encoder(self):
        return self.encoder

    def reorder_decoder_incremental_state(
        self, incremental_state: Dict[int, dict], inds: torch.Tensor
    ) -> Dict[int, dict]:
        """
        Not *quite* sure how to reconcile this with HF.
        """
        return {}

    def eval_decode_forced(self, encoder_states, inputs):

        latent, _ = self.decoder(inputs, encoder_states)
        logits = self.output(latent)
        _, preds = logits.max(dim=2)
        return logits, preds

    def output(self, tensor):
        tensor = tensor * (self.lm3.model_dim ** -0.5)
        lm_logits = self.lm3.lm_head(tensor)
        return lm_logits

    def forward(self, xs1=None, xs2=None,xs3=None,train=True, ys1=None,ys2=None,ys3=None, bart_prev_enc=None,incr_state_gpt2=None, incr_state_lm3=None,maxlen=None, bsz=None):
        if self.train_bart:
            bart_scores, bart_preds, bart_encoder_states = self.bart.model(xs1,train=train,ys=ys1,prev_enc=bart_prev_enc)
        else:
            bart_scores, bart_preds, bart_encoder_states = None, None,None
        if self.train_gpt2:
            gpt2_scores, incr_state_gpt2 = self.gpt2.model(xs2,train=train,ys=ys2,incr_state=incr_state_gpt2)
        else:
            gpt2_scores, incr_state_gpt2 = None, None
        if self.train_lm3:
            lm3_scores, incr_state_lm3 = self.lm3.model(xs3, train=train, ys=ys3, incr_state=incr_state_lm3)
        else:
            lm3_scores, incr_state_lm3 = None, None

        return lm3_scores, incr_state_lm3, gpt2_scores, incr_state_gpt2, bart_scores, bart_preds, bart_encoder_states#, _, _
