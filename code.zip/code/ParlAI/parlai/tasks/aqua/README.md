Task: AQuA
===========
Description: Dataset containing algebraic word problems with rationales for their answers. From Ling et. al. 2017, 

Link: https://arxiv.org/pdf/1705.04146.pdf

Tags: #AQuA, #All, #QA

