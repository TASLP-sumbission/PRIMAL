Task: bAbI 1k
==============
Description: 20 synthetic tasks that each test a unique aspect of text and reasoning, and hence test different capabilities of learning models. From Weston et al. '16. 

Link: http://arxiv.org/abs/1502.05698 

Tags: #bAbI-1k, #All, #QA

Notes: You can access just one of the bAbI tasks with e.g. 'babi:Task1k:3' for task 3.



Task: bAbI 10k
===============
Description: 20 synthetic tasks that each test a unique aspect of text and reasoning, and hence test different capabilities of learning models. From Weston et al. '16. 

Link: http://arxiv.org/abs/1502.05698

Tags: #bAbI-10k, #All, #QA

Notes: You can access just one of the bAbI tasks with e.g. 'babi:Task10k:3' for task 3.

